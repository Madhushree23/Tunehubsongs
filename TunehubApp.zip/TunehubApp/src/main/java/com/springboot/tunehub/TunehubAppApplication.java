package com.springboot.tunehub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TunehubAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TunehubAppApplication.class, args);
	}

}
