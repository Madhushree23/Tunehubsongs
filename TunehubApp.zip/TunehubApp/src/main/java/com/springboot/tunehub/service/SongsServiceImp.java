package com.springboot.tunehub.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.tunehub.entites.Songs;
import com.springboot.tunehub.repository.SongsRepository;

@Service
public class SongsServiceImp implements SongsService {
	SongsRepository rep;

	public SongsServiceImp(SongsRepository rep) {
		super();
		this.rep = rep;
	}

	@Override
	public String addsong(Songs songs) {
		rep.save(songs);
		return "song is added";
	}

	@Override
	public boolean songExists(String name) {
		Songs songs=rep.findByName(name);
		if(songs==null) {
			return false;
		}
		else {
			return true;
		}
		
	}

	@Override
	public List<Songs> fetchAllSongs() {
		List<Songs> songlist=rep.findAll();
		return songlist;
	}

	@Override
	public void updateSong(Songs songs) {
		rep.save(songs);
		// TODO Auto-generated method stub
		
	}
	

}
