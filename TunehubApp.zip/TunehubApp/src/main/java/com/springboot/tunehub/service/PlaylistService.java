package com.springboot.tunehub.service;

import java.util.List;

import com.springboot.tunehub.entites.playlist;

public interface PlaylistService {
	public String addplaylist(playlist playlist);

	public List<playlist> fetchAllSongs();

}
