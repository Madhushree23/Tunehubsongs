package com.springboot.tunehub.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springboot.tunehub.entites.Users;
import com.springboot.tunehub.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
	UserService ser;
	public UserController(UserService ser) {
		super();
		this.ser = ser;
	}

	@PostMapping("/register")
	public String adduser(@ModelAttribute Users users)
	{
		boolean userstatus=ser.emailexist(users.getEmail());
		if(userstatus==false) {
			ser.adduser(users);
			return "registersucess";
		}
		else {

			return "registerfail";
		}
	}
	@PostMapping("/login")
	public String validateuser(@RequestParam String email,@RequestParam String password,HttpSession session){
		if(ser.validateuser(email,password)==true) {
			session.setAttribute("email", email);
			if(ser.getRole(email).equals("admin"))
			{
				return "adminhome";
			}
			else {
				return "customerhome";
			}
		}
		else {
			return "loginfail";
		}
	}
	@GetMapping("/exploresongs")
	public String exploresongs(HttpSession session) {
		String email=(String) session.getAttribute("email");
		Users user = ser.getUsers(email); // Get user by email

		

		boolean userStatus = user.isPremium();

		if(userStatus == true) {
			return "displaysongs";
		}
		else {
			return "samplepayment";
		}

	}
}

