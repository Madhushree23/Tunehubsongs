package com.springboot.tunehub.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.tunehub.entites.playlist;
import com.springboot.tunehub.repository.PlaylistRepository;

@Service
public class PlaylistSeviceImp implements PlaylistService {
	PlaylistRepository prep;

	public PlaylistSeviceImp(PlaylistRepository prep) {
		super();
		this.prep = prep;
	}

	@Override
	public String addplaylist(playlist playlist) {
		prep.save(playlist);
		return "addedplaylist";

	}

	@Override
	public List<playlist> fetchAllSongs() {
		return prep.findAll();

	}
}
