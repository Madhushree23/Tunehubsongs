package com.springboot.tunehub.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.tunehub.entites.Users;

public interface UserRepository extends JpaRepository<Users, Integer> {
public Users findByEmail(String email);
}
