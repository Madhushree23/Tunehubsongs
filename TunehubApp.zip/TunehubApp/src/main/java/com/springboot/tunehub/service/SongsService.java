package com.springboot.tunehub.service;

import java.util.List;

import com.springboot.tunehub.entites.Songs;

public interface SongsService {

	public String addsong(Songs songs);
	public boolean songExists(String name);
	public List<Songs> fetchAllSongs();
	public void updateSong(Songs songs);

}
