package com.springboot.tunehub.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springboot.tunehub.entites.Songs;
import com.springboot.tunehub.service.SongsService;

@Controller
public class SongsController {
	SongsService ser;

	
public SongsController(SongsService ser) {
		super();
		this.ser = ser;
	}


@PostMapping("/addsong")
public String addsong(@ModelAttribute Songs songs) {
	boolean status=ser.songExists(songs.getName());
	if(status==false) {
	 ser.addsong(songs);
	 return "songsucess";
	}
	else {
		return "songfail";
	}
	

}
@GetMapping("/map-viewsongs")
public String viewsongs(Model m) {
	List<Songs> songlist=ser.fetchAllSongs();
	m.addAttribute("songlist", songlist);
	return "displaysongs" ;
	
}
@GetMapping("/viewsongs")
public String viewCustomerSongs(Model m) {
	boolean primestatus=true;
	if(primestatus==true) {
		List<Songs> songlist=ser.fetchAllSongs();
		m.addAttribute("songlist", songlist);
		return "displaysongs" ;
	}
	else {
		return "makepayment";
	}
	
}


}
