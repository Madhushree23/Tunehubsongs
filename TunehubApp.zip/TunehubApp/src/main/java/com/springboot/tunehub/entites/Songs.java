package com.springboot.tunehub.entites;

import java.util.List;

import org.hibernate.annotations.ManyToAny;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;

@Entity
public class Songs {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	
	String name;
	
	String artist;
	
	String link;
	
	@ManyToMany
	List<playlist> playlist;
	public Songs(int id, String name, String artist, String link,
			List<com.springboot.tunehub.entites.playlist> playlist) {
		super();
		this.id = id;
		this.name = name;
		this.artist = artist;
		this.link = link;
		this.playlist = playlist;
	}
	public Songs() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Songs [id=" + id + ", name=" + name + ", artist=" + artist + ", link=" + link + ", playlist=" + playlist
				+ "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public List<playlist> getPlaylist() {
		return playlist;
	}
	public void setPlaylist(List<playlist> playlist) {
		this.playlist = playlist;
	}
}