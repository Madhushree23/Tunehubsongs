package com.springboot.tunehub.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class NavController {
	
	@GetMapping("/map-register")
	public String mapregister() {
		return "register";
	}
	
	@GetMapping("/map-login")
	public String maplogin() {
		return "login";
	}
	@GetMapping("/map-addsongs")
	public String mapaddsongs() {
		return "addsongs";
	}
	@GetMapping("/samplepayment")
	public String sample() {
		return "samplepayment";
	}
	

}
