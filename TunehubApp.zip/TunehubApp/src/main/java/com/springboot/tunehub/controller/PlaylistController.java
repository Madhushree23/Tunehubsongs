package com.springboot.tunehub.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.springboot.tunehub.entites.Songs;
import com.springboot.tunehub.entites.playlist;
import com.springboot.tunehub.service.PlaylistService;
import com.springboot.tunehub.service.SongsService;

@Controller
public class PlaylistController {
	PlaylistService pserv;

	public PlaylistController(PlaylistService pserv) {
		super();
		this.pserv = pserv;
	}
	@Autowired
	SongsService ser;
	@GetMapping("/createplaylist")
	public String createPlaylist(Model m) {
		List<Songs> songlist=ser.fetchAllSongs();
		m.addAttribute("songlist", songlist);
		
		
		return "createplaylist";
	}

	@PostMapping("/addplaylist")
	public String addPlayList(@ModelAttribute playlist playlist) {
	
		pserv.addplaylist(playlist);
		List<Songs> songlist=playlist.getSongs();
		for(Songs songs:songlist) {
			songs.getPlaylist().add(playlist);
			ser.updateSong(songs);
		}
		return "playlistsucess";

}
	@GetMapping("/viewplaylist")
	public String viewPlaylist(Model m) {
	List<playlist> plist=	pserv.fetchAllSongs();
		m.addAttribute("plist",plist);
		return "viewplaylist";
	}
	}

