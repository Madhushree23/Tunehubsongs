package com.springboot.tunehub.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.tunehub.entites.Users;
import com.springboot.tunehub.repository.UserRepository;
@Service
public class UserServiceImp implements UserService {

public UserServiceImp(UserRepository urep) {
		super();
		this.urep = urep;
	}
UserRepository urep;
	@Override
	public String adduser(Users users) {
		urep.save(users);
		return "saved";
	}
	
	
	@Override
	public boolean emailexist(String email) {
		
		if(urep.findByEmail(email)==null) {
			return false;
		}
		else {
		return true;
	}
	}
	@Override
	public boolean validateuser(String email, String password) {
		Users users=urep.findByEmail(email);
		String db_password=users.getPassword();
		// TODO Auto-generated method stub
		if(db_password.equals(password)) {
			return true;
		}
		else {
		return false;
		}
	}


	@Override
	public String getRole(String email) {
		return (urep.findByEmail(email).getRole());
	}


	@Override
	public Users getUsers(String email) {
		return urep.findByEmail(email);
	}


	@Override
	public void updateUser(Users user) {
		urep.save(user);
	}
	

}
