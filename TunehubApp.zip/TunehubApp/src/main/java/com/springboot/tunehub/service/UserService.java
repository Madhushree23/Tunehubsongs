package com.springboot.tunehub.service;

import com.springboot.tunehub.entites.Users;

public interface UserService {
	public String adduser(Users users);
	public boolean emailexist(String email);
	public boolean validateuser(String email, String password);
public String getRole(String email);
public Users getUsers(String email);
public void updateUser(Users user);
}
