package com.springboot.tunehub.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.tunehub.entites.playlist;

public interface PlaylistRepository extends JpaRepository<playlist, Integer>{

}
