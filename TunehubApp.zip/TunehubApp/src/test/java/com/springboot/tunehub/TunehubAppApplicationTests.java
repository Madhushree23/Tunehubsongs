package com.springboot.tunehub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TunehubAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
